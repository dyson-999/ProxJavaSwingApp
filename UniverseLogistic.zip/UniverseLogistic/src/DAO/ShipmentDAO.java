package DAO;

import database.Database;
import models.Shipment;

import java.util.List;

public class ShipmentDAO {
    private final Database db;

    public ShipmentDAO() {
        db = Database.getInstance();  // Getting the singleton instance
    }

    public List<Shipment> getAllShipments() {
        return db.getShipments();  // Returning all shipments from the Database instance
    }

    public void updateShipment(Shipment updatedShipment) {
        for (Shipment s : db.getShipments()) {
            if (s.getId() == updatedShipment.getId()) {
                s.setAssigned(updatedShipment.isAssigned());
                s.setAssignedDriver(updatedShipment.getAssignedDriver());
                break;
            }
        }
    }
}
