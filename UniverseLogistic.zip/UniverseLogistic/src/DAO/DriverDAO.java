package DAO;

import database.Database;
import models.Driver;

import java.util.List;

public class DriverDAO {
    private final Database db;

    public DriverDAO() {
        db = Database.getInstance();
    }

    public List<Driver> getAllDrivers() {
        return db.getDrivers();
    }

    public void updateDriver(Driver updatedDriver) {
        for (Driver d : db.getDrivers()) {
            if (d.getId() == updatedDriver.getId()) {
                d.setAvailable(updatedDriver.isAvailable());
                break;
            }
        }
    }
}
