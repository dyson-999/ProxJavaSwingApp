import DAO.DriverDAO;
import DAO.ShipmentDAO;
import database.Database;
import models.Driver;
import models.Shipment;
import services.AssignmentService;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Create DAO instances
        DriverDAO driverDAO = new DriverDAO();
        ShipmentDAO shipmentDAO = new ShipmentDAO();

        // Create the AssignmentService instance with the DAOs
        AssignmentService service = new AssignmentService(driverDAO, shipmentDAO);

        // Retrieve the drivers and shipments from the database
        List<Driver> drivers = driverDAO.getAllDrivers();
        List<Shipment> shipments = shipmentDAO.getAllShipments();

        // Print shipments before assignment
        System.out.println("Before assignment:");
        for (Shipment s : shipments) {
            System.out.println(s);
        }

        // Assign drivers to shipments
        System.out.println("\nAssigning drivers...");
        service.assignDriverToShipment(drivers.get(0), shipments.get(0));
        service.assignDriverToShipment(drivers.get(1), shipments.get(1));

        // Print shipments after assignment
        System.out.println("\nAfter assignment:");
        for (Shipment s : shipments) {
            System.out.println(s);
        }
    }
}
