package services;

import DAO.DriverDAO;
import DAO.ShipmentDAO;
import models.Driver;
import models.Shipment;

public class AssignmentService {
    private DriverDAO driverDAO;
    private ShipmentDAO shipmentDAO;

    // Constructor to initialize DAOs
    public AssignmentService(DriverDAO driverDAO, ShipmentDAO shipmentDAO) {
        this.driverDAO = driverDAO;
        this.shipmentDAO = shipmentDAO;
    }

    // Method to assign a driver to a shipment
    public boolean assignDriverToShipment(Driver driver, Shipment shipment) {
        // Check if either the driver or shipment is null
        if (driver == null || shipment == null) {
            System.out.println("Driver or Shipment is null.");
            return false;
        }

        // Check if the driver is available
        if (!driver.isAvailable()) {
            System.out.println("Driver is not available.");
            return false;
        }

        // Check if the shipment is already assigned
        if (shipment.isAssigned()) {
            System.out.println("Shipment is already assigned.");
            return false;
        }

        // Perform the assignment
        shipment.setAssignedDriver(driver);  // Assign the driver to the shipment
        shipment.setAssigned(true);           // Mark the shipment as assigned
        driver.setAvailable(false);           // Mark the driver as unavailable

        // Persist the updated data
        driverDAO.updateDriver(driver);  // Update driver in the database
        shipmentDAO.updateShipment(shipment);  // Update shipment in the database

        // Output success message
        System.out.println("SUCCESS: Assigned " + driver.getName() + " to Shipment " + shipment.getId());
        return true;
    }
}
