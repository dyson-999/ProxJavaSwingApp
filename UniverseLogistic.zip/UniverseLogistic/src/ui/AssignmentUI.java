package ui;

import database.Database;
import models.Driver;
import models.Shipment;
import services.AssignmentService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class AssignmentUI {
    private JFrame frame;
    private JComboBox<Driver> driverComboBox;
    private JComboBox<Shipment> shipmentComboBox;
    private JTextArea resultArea;

    private Database db;
    private AssignmentService assignmentService;

    public AssignmentUI() {
        db = new Database(); // simulate database
        assignmentService = new AssignmentService(); // logic handler

        initializeUI();
    }

    private void initializeUI() {
        frame = new JFrame("Assign Drivers to Shipments");
        frame.setSize(500, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create components
        JLabel driverLabel = new JLabel("Select Driver:");
        driverComboBox = new JComboBox<>();
        loadAvailableDrivers();

        JLabel shipmentLabel = new JLabel("Select Shipment:");
        shipmentComboBox = new JComboBox<>();
        loadUnassignedShipments();

        JButton assignButton = new JButton("Assign Driver");
        resultArea = new JTextArea(5, 30);
        resultArea.setEditable(false);

        // Add components to panel
        inputPanel.add(driverLabel);
        inputPanel.add(driverComboBox);
        inputPanel.add(shipmentLabel);
        inputPanel.add(shipmentComboBox);
        inputPanel.add(new JLabel()); // spacer
        inputPanel.add(assignButton);

        // Add listeners
        assignButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                assignDriverToShipment();
            }
        });

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(resultArea), BorderLayout.CENTER);

        frame.setVisible(true);
    }

    private void loadAvailableDrivers() {
        driverComboBox.removeAllItems();
        for (Driver d : db.getDrivers()) {
            if (d.isAvailable()) {
                driverComboBox.addItem(d);
            }
        }
    }

    private void loadUnassignedShipments() {
        shipmentComboBox.removeAllItems();
        for (Shipment s : db.getShipments()) {
            if (!s.isAssigned()) {
                shipmentComboBox.addItem(s);
            }
        }
    }

    private void assignDriverToShipment() {
        Driver selectedDriver = (Driver) driverComboBox.getSelectedItem();
        Shipment selectedShipment = (Shipment) shipmentComboBox.getSelectedItem();

        if (selectedDriver == null || selectedShipment == null) {
            resultArea.setText("Please select both a driver and a shipment.");
            return;
        }

        boolean success = assignmentService.assignDriverToShipment(selectedDriver, selectedShipment);
        if (success) {
            resultArea.setText("✅ Assigned " + selectedDriver.getName() + " to shipment " + selectedShipment.getId());
        } else {
            resultArea.setText("❌ Failed to assign driver. Check availability or shipment status.");
        }

        // Refresh dropdowns
        loadAvailableDrivers();
        loadUnassignedShipments();
    }

    // To launch the UI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AssignmentUI());
    }
}
