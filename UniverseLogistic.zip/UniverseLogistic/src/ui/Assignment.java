package ui;

import DAO.DriverDAO;
import DAO.ShipmentDAO;
import models.Driver;
import models.Shipment;
import services.AssignmentService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class Assignment {

    private JButton assignButton;
    private JComboBox<Driver> driverComboBox;
    private JComboBox<Shipment> shipmentComboBox;
    private JTextArea resultArea;
    private JPanel panel1;

    private DAO.DriverDAO driverDAO;
    private DAO.ShipmentDAO shipmentDAO;
    private AssignmentService assignmentService;

    public Assignment() {
        driverDAO = new DriverDAO();
        shipmentDAO = new ShipmentDAO();
        assignmentService = new AssignmentService(driverDAO, shipmentDAO);

        // Initialize UI components
        initializeUI();
        loadDrivers();
        loadShipments();
    }

    // Automatically called by the NetBeans GUI Builder
    private void createUIComponents() {
        // Here you can create custom components that can't be done using the GUI builder directly

        // Example: Creating a custom driverComboBox with a custom renderer
        driverComboBox = new JComboBox<Driver>() {
            @Override
            public void setPopupVisible(boolean v) {
                super.setPopupVisible(v);
            }
        };

        // You can also add custom listeners here if needed
        driverComboBox.addActionListener(e -> {
            // Custom action for driver selection
            Driver selectedDriver = (Driver) driverComboBox.getSelectedItem();
            System.out.println("Selected driver: " + selectedDriver.getName());
        });
    }

    private void initializeUI() {
        // Use the GUI components created from the .form file or initialized in createUIComponents
        panel1 = new JPanel();
        assignButton = new JButton("Assign");
        driverComboBox = new JComboBox<>();
        shipmentComboBox = new JComboBox<>();
        resultArea = new JTextArea(5, 30);

        // Set up layout for the components
        panel1.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Setup GUI layout (this part is simplified and should match your .form layout)
        gbc.gridx = 0; gbc.gridy = 0;
        panel1.add(new JLabel("Select Driver:"), gbc);
        gbc.gridx = 1;
        panel1.add(driverComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel1.add(new JLabel("Select Shipment:"), gbc);
        gbc.gridx = 1;
        panel1.add(shipmentComboBox, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        panel1.add(assignButton, gbc);

        gbc.gridy = 3;
        panel1.add(new JScrollPane(resultArea), gbc);

        // Add action listener to the assign button
        assignButton.addActionListener(e -> assignDriver());

        // Finalize frame settings
        JFrame frame = new JFrame("Assign Driver to Shipment");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 300);
        frame.add(panel1);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    // Method to load available drivers
    private void loadDrivers() {
        driverComboBox.removeAllItems();
        List<Driver> drivers = driverDAO.getAllDrivers();
        for (Driver d : drivers) {
            if (d.isAvailable()) {
                driverComboBox.addItem(d);
            }
        }
    }

    // Method to load available shipments
    private void loadShipments() {
        shipmentComboBox.removeAllItems();
        List<Shipment> shipments = shipmentDAO.getAllShipments();
        for (Shipment s : shipments) {
            if (!s.isAssigned()) {
                shipmentComboBox.addItem(s);
            }
        }
    }

    // Method to assign driver to shipment
    private void assignDriver() {
        Driver driver = (Driver) driverComboBox.getSelectedItem();
        Shipment shipment = (Shipment) shipmentComboBox.getSelectedItem();

        if (driver == null || shipment == null) {
            resultArea.setText("⚠️ Please select both a driver and a shipment.");
            return;
        }

        boolean success = assignmentService.assignDriverToShipment(driver, shipment);

        if (success) {
            resultArea.setText("✅ Assigned " + driver.getName() + " to shipment " + shipment.getId());
        } else {
            resultArea.setText("❌ Assignment failed.");
        }

        loadDrivers();
        loadShipments();
    }

    // Main method to run the GUI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Assignment::new);
    }
}
