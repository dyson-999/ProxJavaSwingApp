package database;

import models.Driver;
import models.Shipment;
import java.util.ArrayList;
import java.util.List;

public class Database {
    private static Database instance;  // Singleton instance
    private List<Driver> drivers;
    private List<Shipment> shipments;

    // Private constructor to prevent external instantiation
    private Database() {
        drivers = new ArrayList<>();
        shipments = new ArrayList<>();

        // Dummy data for testing
        drivers.add(new Driver(1, "Alice"));
        drivers.add(new Driver(2, "Bob"));
        drivers.add(new Driver(3, "Charlie"));

        shipments.add(new Shipment(100, "New York"));
        shipments.add(new Shipment(101, "Los Angeles"));
        shipments.add(new Shipment(102, "Chicago"));
    }

    // Public method to get the single instance of Database
    public static Database getInstance() {
        if (instance == null) {
            instance = new Database();
        }
        return instance;
    }

    // Methods to get drivers and shipments
    public List<Driver> getDrivers() {
        return drivers;
    }

    public List<Shipment> getShipments() {
        return shipments;
    }
}
