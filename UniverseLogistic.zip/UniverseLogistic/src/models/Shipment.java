package models;

public class Shipment {
    private int id;
    private String destination;
    private boolean isAssigned;
    private Driver assignedDriver;

    public Shipment(int id, String destination) {
        this.id = id;
        this.destination = destination;
        this.isAssigned = false;
        this.assignedDriver = null;
    }

    public int getId() {
        return id;
    }

    public String getDestination() {
        return destination;
    }

    public boolean isAssigned() {
        return isAssigned;
    }

    public void setAssigned(boolean assigned) {
        this.isAssigned = assigned;
    }

    public Driver getAssignedDriver() {
        return assignedDriver;
    }

    public void setAssignedDriver(Driver driver) {
        this.assignedDriver = driver;
        this.isAssigned = (driver != null);
    }

    @Override
    public String toString() {
        String assignedInfo = isAssigned ? "Assigned to " + assignedDriver.getName() : "Unassigned";
        return "Shipment ID: " + id + ", Destination: " + destination + ", " + assignedInfo;
    }
}
