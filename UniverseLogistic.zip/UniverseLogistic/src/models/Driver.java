package models;

public class Driver {
    private int id;
    private String name;
    private boolean isAvailable;

    public Driver(int id, String name) {
        this.id = id;
        this.name = name;
        this.isAvailable = true; // default to available
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        this.isAvailable = available;
    }

    @Override
    public String toString() {
        return name + " (ID: " + id + ", Available: " + isAvailable + ")";
    }
}
